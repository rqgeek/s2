package ARITHOP;
public class Division{
	public float divide(float a,float b){
		return a/b;
	}
}

