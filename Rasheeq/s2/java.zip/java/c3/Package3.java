package ARITHOP;
public class Addition{
	int add(int x,int y){
		return x+y;
	}
}
public class Subtraction{
	int subtract(int x,int y){
		return x-y;
	}
}
public class Multiplication{
	int multiply(int x,int y){
		return x*y;
	}
}
class Division{
	float divide(int x,int y){
		return x/y;
	}
}
